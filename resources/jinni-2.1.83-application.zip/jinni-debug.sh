#!/bin/bash
echo Deprecation: please use the bin folder for execution and the new option syntax
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
CP=$DIR/lib/'*'
java -cp "$CP" -Djinni.legacy.options=true -Djinni.installationDir "$DIR" -Xdebug -Xrunjdwp:server=y,transport=dt_socket,address=4000,suspend=y com.braintribe.tribefire.jinni.Jinni "$@"